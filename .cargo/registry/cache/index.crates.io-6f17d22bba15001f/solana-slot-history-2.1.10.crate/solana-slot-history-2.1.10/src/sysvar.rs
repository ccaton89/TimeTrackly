use {crate::SlotHistory, solana_sysvar_id::declare_sysvar_id};

declare_sysvar_id!("SysvarS1otHistory11111111111111111111111111", SlotHistory);
