# Pod

This library contains types shared by SPL libraries that implement the `Pod` trait from `bytemuck` and utils for working with these types.
