use {crate::SlotHashes, solana_sysvar_id::declare_sysvar_id};

declare_sysvar_id!("SysvarS1otHashes111111111111111111111111111", SlotHashes);
