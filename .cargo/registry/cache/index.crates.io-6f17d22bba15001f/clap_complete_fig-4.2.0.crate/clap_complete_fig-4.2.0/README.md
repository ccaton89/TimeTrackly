# clap_complete_fig

Generates [Fig](https://github.com/withfig/autocomplete) completions for [`clap`](https://github.com/clap-rs/clap) based CLIs

<!-- * [Documentation][docs] -->
- [Questions & Discussions](https://github.com/clap-rs/clap/discussions)
- [CONTRIBUTING](../CONTRIBUTING.md)

<!-- [docs]: https://docs.rs/clap_complete_fig -->
