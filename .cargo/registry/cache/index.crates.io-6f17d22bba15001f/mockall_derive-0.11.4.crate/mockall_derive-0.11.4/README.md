# Mockall_derive

This crate should never be used directly.  You should use
[`mockall`](https://crates.io/crates/mockall) instead.

# License

`mockall` is primarily distributed under the terms of both the MIT license
and the Apache License (Version 2.0), with portions covered by various BSD-like
licenses.

See LICENSE-APACHE, and LICENSE-MIT for details


