import { S as t, B as n, C as o } from "./commonDb-41f8b4c5.js";
function a(e) {
  return typeof e == "string" ? new t([document.querySelectorAll(e)], [document.documentElement]) : new t([o(e)], n);
}
export {
  a as s
};
//# sourceMappingURL=selectAll-4d781168.js.map
