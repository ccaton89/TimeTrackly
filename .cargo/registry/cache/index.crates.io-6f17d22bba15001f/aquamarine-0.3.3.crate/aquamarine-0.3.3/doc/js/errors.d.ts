export declare class UnknownDiagramError extends Error {
    constructor(message: string);
}
