use {crate::Clock, solana_sysvar_id::declare_sysvar_id};

declare_sysvar_id!("SysvarC1ock11111111111111111111111111111111", Clock);
