//! Solana SVM Rent Collector.
//!
//! Rent management for SVM.

pub mod rent_state;
pub mod svm_rent_collector;
