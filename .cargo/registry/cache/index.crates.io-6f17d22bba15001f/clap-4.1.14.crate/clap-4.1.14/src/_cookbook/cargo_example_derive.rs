//! # Example: cargo subcommand (Derive API)
//!
//! ```rust
#![doc = include_str!("../../examples/cargo-example-derive.rs")]
//! ```
//!
#![doc = include_str!("../../examples/cargo-example-derive.md")]
