A fork of [paste](https://github.com/dtolnay/paste) using lowerCamelCase instead of UpperCamelCase (PascalCase).

Hopefully temporary.
