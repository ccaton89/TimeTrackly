use camelpaste::paste;

paste! {
    fn [<a:pillow>]() {}
}

fn main() {}
