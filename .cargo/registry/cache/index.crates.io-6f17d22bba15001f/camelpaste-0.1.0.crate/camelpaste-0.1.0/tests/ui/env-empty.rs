use camelpaste::paste;

paste! {
    fn [<env!()>]() {}
}

fn main() {}
