use camelpaste::paste;

paste! {
    fn [<a + b>]() {}
}

fn main() {}
