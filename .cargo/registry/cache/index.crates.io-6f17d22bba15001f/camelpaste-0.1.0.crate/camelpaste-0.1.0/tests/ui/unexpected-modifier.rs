use camelpaste::paste;

paste! {
    fn [<:lower x>]() {}
}

fn main() {}
