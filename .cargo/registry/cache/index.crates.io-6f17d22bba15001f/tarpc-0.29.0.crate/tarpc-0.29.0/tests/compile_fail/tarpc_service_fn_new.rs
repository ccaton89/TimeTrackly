#[tarpc::service]
trait World {
    async fn new();
}

fn main() {}
