//! The [system native program][np].
//!
//! [np]: https://docs.solanalabs.com/runtime/programs#system-program

crate::declare_id!("11111111111111111111111111111111");
