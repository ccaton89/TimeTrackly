#[derive(num_enum::FromPrimitive)]
#[repr(u8)]
enum Numbers {
    Zero,
    One,
    Two,
}

fn main() {

}
