use {crate::Rent, solana_sysvar_id::declare_sysvar_id};

declare_sysvar_id!("SysvarRent111111111111111111111111111111111", Rent);
