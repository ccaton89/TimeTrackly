/// libiconv.tbd
pub static LIBICONV_TBD: &str = include_str!("libiconv.tbd");
/// libcharset.tbd
pub static LIBCHARSET_TBD: &str = include_str!("libcharset.1.tbd");
