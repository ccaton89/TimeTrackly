use {crate::EpochSchedule, solana_sysvar_id::declare_sysvar_id};

declare_sysvar_id!("SysvarEpochSchedu1e111111111111111111111111", EpochSchedule);
