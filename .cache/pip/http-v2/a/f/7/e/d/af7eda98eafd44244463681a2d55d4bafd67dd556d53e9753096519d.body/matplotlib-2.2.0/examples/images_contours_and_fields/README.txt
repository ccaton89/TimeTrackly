.. _images_contours_and_fields_examples:

Images, contours and fields
===========================
