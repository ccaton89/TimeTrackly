.. _text_labels_and_annotations:

Text, labels and annotations
============================
