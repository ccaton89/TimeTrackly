Widgets
=======

Examples of how to write primitive, but GUI agnostic, widgets in
matplotlib
