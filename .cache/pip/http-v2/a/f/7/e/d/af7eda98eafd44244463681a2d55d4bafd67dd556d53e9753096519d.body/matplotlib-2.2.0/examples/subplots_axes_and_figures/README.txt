.. _subplots_axes_and_figures_examples:

Subplots, axes and figures
==========================
