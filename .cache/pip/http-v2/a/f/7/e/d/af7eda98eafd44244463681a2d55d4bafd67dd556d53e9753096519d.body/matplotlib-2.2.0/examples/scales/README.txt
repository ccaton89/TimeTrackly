.. _scales_examples:

Scales
======

These examples cover how different scales are handled in Matplotlib.
